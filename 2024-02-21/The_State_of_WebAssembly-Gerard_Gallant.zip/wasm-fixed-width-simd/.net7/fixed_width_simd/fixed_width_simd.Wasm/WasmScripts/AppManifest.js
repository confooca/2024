var UnoAppManifest = {
    displayName: "fixed_width_simd"
}
