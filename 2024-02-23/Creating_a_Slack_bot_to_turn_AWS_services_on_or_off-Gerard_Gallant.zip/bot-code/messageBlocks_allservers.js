module.exports.messageTemplate_allServers = {
	"blocks": [
		{
			"type": "section",
			"block_id": "RefreshStatuses",
			"text": {
				"type": "mrkdwn",
				"text": "*Test Servers*"
			},
			"accessory": {
				"type": "button",
				"text": {
					"type": "plain_text",
					"text": ":repeat: Refresh"
				},
				"action_id": "RefreshStatuses",
				"value": "Layout_all"
			}
		},
		{
			"type": "context",
			"block_id": "LastCheckedSummary",
			"elements": [
				{
					"type": "mrkdwn",
					"text": "Server statuses are checked hourly"
				}
			]
		},
		{
			"type": "section",
			"block_id": "TurnOnOff_Dev",
			"text": {
				"type": "mrkdwn",
				"text": "*Dev*"
			},
			"accessory": {
				"type": "button",
				"text": {
					"type": "plain_text",
					"text": "Turn On"
				},
				"action_id": "TurnOnOff_Dev"
			}
		},
		{
			"type": "context",
			"block_id": "InUseBy_Dev",
			"elements": [
				{
					"type": "mrkdwn",
					"text": " "
				}
			]
		},
		{
			"type": "actions",
			"block_id": "FlagInUse_Dev",
			"elements": [
				{
					"type": "button",
					"text": {
						"type": "plain_text",
						"text": ":triangular_flag_on_post:"
					},
					"action_id": "FlagInUse_Dev"
				}
			]
		},
		{
			"type": "divider",
			"block_id": "Divider1"
		},
		{
			"type": "section",
			"block_id": "TurnOnOff_QA",
			"text": {
				"type": "mrkdwn",
				"text": "*QA*"
			},
			"accessory": {
				"type": "button",
				"text": {
					"type": "plain_text",
					"text": "Turn On"
				},
				"action_id": "TurnOnOff_QA"
			}
		},
		{
			"type": "context",
			"block_id": "InUseBy_QA",
			"elements": [
				{
					"type": "mrkdwn",
					"text": " "
				}
			]
		},
		{
			"type": "actions",
			"block_id": "FlagInUse_QA",
			"elements": [
				{
					"type": "button",
					"text": {
						"type": "plain_text",
						"text": ":triangular_flag_on_post:"
					},
					"action_id": "FlagInUse_QA"
				}
			]
		}
	]
};