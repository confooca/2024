module.exports.messageTemplate_Dev = {
	"blocks": [
		{
			"type": "section",
			"block_id": "RefreshStatuses",
			"text": {
				"type": "mrkdwn",
				"text": "*Test Servers*"
			},
			"accessory": {
				"type": "button",
				"text": {
					"type": "plain_text",
					"text": ":repeat: Refresh"
				},
				"action_id": "RefreshStatuses",
				"value": "Layout_dev"
			}
		},
		{
			"type": "context",
			"block_id": "LastCheckedSummary",
			"elements": [
				{
					"type": "mrkdwn",
					"text": "Server statuses are checked hourly"
				}
			]
		},
		{
			"type": "section",
			"block_id": "TurnOnOff_Dev",
			"text": {
				"type": "mrkdwn",
				"text": "*Dev*"
			},
			"accessory": {
				"type": "button",
				"text": {
					"type": "plain_text",
					"text": "Turn On"
				},
				"action_id": "TurnOnOff_Dev"
			}
		},
		{
			"type": "context",
			"block_id": "InUseBy_Dev",
			"elements": [
				{
					"type": "mrkdwn",
					"text": " "
				}
			]
		},
		{
			"type": "actions",
			"block_id": "FlagInUse_Dev",
			"elements": [
				{
					"type": "button",
					"text": {
						"type": "plain_text",
						"text": ":triangular_flag_on_post:"
					},
					"action_id": "FlagInUse_Dev"
				}
			]
		}
	]
};